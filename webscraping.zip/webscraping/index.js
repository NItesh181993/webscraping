const request = require('request');
const cheerio = require('cheerio');
const app = require('express')();
const bodyParser = require('body-parser');
var port = process.env.PORT || 3000;

//support parsing of application/json type post data
app.use(bodyParser.json());

//support parsing of application/x-www-form-urlencoded post data
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/scrap', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    var url = req.body.url;
    console.log(url);
 
    //make a new request to the URL provided in the HTTP POST request

    request(url, function (error, response, responseHtml) {
        var resObj = {};

        //if there was an error
        // if (error) {
        //     res.end(JSON.stringify({error:'Could not scrape URL because it was malformed'}));
        //     return;
        // }

        if (error) throw Error('Could not scrape URL because it was malformed');


        //create the cheerio object
        resObj = {},
            //set a reference to the document that came back
            $ = cheerio.load(responseHtml),
            //create a reference to the meta elements
            $title = $('head title').text(),
            $desc = $('meta[name="description"]').attr('content'),
            $kwd = $('meta[name="keywords"]').attr('content'),
            $ogTitle = $('meta[property="og:title"]').attr('content'),
            $ogImage = $('meta[property="og:image"]').attr('content'),
            $ogkeywords = $('meta[property="og:keywords"]').attr('content'),
            $images = $('img');

        if ($title) {
            resObj.title = $title;
        }

        if ($desc) {
            resObj.description = $desc;
        }

        if ($kwd) {
            resObj.keywords = $kwd;
        }

        if ($ogImage && $ogImage.length) {
            resObj.ogImage = $ogImage;
        }

        if ($ogTitle && $ogTitle.length) {
            resObj.ogTitle = $ogTitle;
        }

        if ($ogkeywords && $ogkeywords.length) {
            resObj.ogkeywords = $ogkeywords;
        }

        if ($images && $images.length) {
            resObj.images = [];

            for (var i = 0; i < $images.length; i++) {
                resObj.images.push($($images[i]).attr('src'));
            }
        }

        //send the response
        console.log(resObj);
        res.end(JSON.stringify(resObj));
    });
});

//listen for an HTTP request
app.listen(port, () => {
    console.log(`Server running on Port:${port}`);
});

//just so we know the server is running
console.log('Navigate your browser to: http://localhost:3000');
console.log('Dont forget to Add http or https');
